# simple_crud
This is a simple PYTHON database package that allows user to manipulate data (create, read, update and delete) using sql statement queries. The user won't have to write the whole sql statement, just call the function associated with the statement query, provide arguments and will be executed for them. 

# Database 
This package is built using the sqlite3 (as this DBMS is provided as a python builtin tool) and currently can be used with it. 

# What to download to run the project:
Your PC must have python3 to run the project. The python programming language can be downloaded using this following link:
https://www.python.org/downloads/

# Troubleshooting the Package:
Should any issues arise while using the package: 
~ Use the issues board on github for the project you have issues with, you can assign me and I will comment back as soon as I get the time.

OR : You can email me at lindokuhlerajuili@gmail.com with the name of the project as the subject.
